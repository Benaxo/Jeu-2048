﻿using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Jeu2048
{
    public class ClassCaseJeu : Label
    {
        private static readonly List<Color> ListCouleurs = new List<Color>() { Color.Azure, Color.Azure, Color.Khaki, Color.Orange, Color.OrangeRed, Color.Red, Color.LightPink, Color.GreenYellow, Color.Gray, Color.LightBlue, Color.Cyan, Color.Gold };
        private static readonly List<int> ListValeurs = new List<int>() { 0, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048 };

        public static int TotalScore { get; set; } // score atteint durant le jeu
        public int Valeur { get; set; } // nombre inscrit dans la case
        
        public ClassCaseJeu(int Index, int CaseLeft, int CaseTop)
        {
            BackColor = Color.Azure;
            Name = "Case" + (Index).ToString();
            Size = new Size(130, 130);
            Location = new Point(CaseLeft, CaseTop);
            BorderStyle = BorderStyle.FixedSingle;
            TextAlign = ContentAlignment.MiddleCenter;
            Font = new Font("Tahoma", 28, FontStyle.Bold);
            Valeur = 0;
        }

        /// <summary>
        /// Affichage de la couleur des cases et calcul du score total 
        /// </summary>
        /// <param name="ListCases"></param>
        public static void AfficheCouleur(List<ClassCaseJeu> ListCases)
        {
            TotalScore = 0;
            for (int i = 0; i <= 15; i++)
            {
                int Index = i;
                int IndexValeur = ListValeurs.FindIndex(p => p == ListCases[Index].Valeur);
                ListCases[i].BackColor = ListCouleurs[IndexValeur];
                TotalScore += ListCases[i].Valeur;
            }
        }

        /// <summary>
        /// Déplacement des cases selon direction
        /// </summary>
        /// <param name="ListIntValues"></param>
        public static void Deplacement(List<int> ListIntValues, List<ClassCaseJeu> ListCases)
        {
            // on traite chaque ligne de 4 cases selon le sens bas, haut, droite ou gauche
            // On fusionne les cases de même valeur
            ClassCaseJeu CaseJeu;
            for (int i = 0; i <= ListIntValues.Count - 1; i += 4)
                for (int j = 0; j <= 2; j++) // on ne fait rien pour la dernière case de la ligne ou colonne
                {
                    CaseJeu = ListCases[ListIntValues[i + j]];
                    if (CaseJeu.Valeur != 0)
                        // test si fusion possible avec la case qui suit
                        if (CaseJeu.Valeur == ListCases[ListIntValues[i + j + 1]].Valeur)
                        {
                            CaseJeu.Text = string.Empty; // on vide la case
                            ListCases[ListIntValues[i + j + 1]].Valeur = CaseJeu.Valeur * 2; // on double la case suivante selon la direction
                            ListCases[ListIntValues[i + j + 1]].Text = (CaseJeu.Valeur * 2).ToString();
                            CaseJeu.Valeur = 0;
                        }
                }
            // On fait les décalages pour supprimer les cases vides
            for (int i = 0; i <= ListIntValues.Count - 1; i += 4)
            {
                List<int> Valeurs = new List<int>();
                for (int j = 0; j <= 3; j++)
                {
                    CaseJeu = ListCases[ListIntValues[i + j]];
                    CaseJeu.Text = string.Empty;
                    if (CaseJeu.Valeur != 0)
                        Valeurs.Add(ListCases[ListIntValues[i + j]].Valeur);
                }
                if (Valeurs.Count != 0)
                {
                    while (Valeurs.Count < 4)
                        Valeurs.Insert(0, 0);
                    for (int j = 0; j <= 3; j++)
                    {
                        CaseJeu = ListCases[ListIntValues[i + j]];
                        CaseJeu.Valeur = Valeurs[j];
                        if (CaseJeu.Valeur != 0)
                            CaseJeu.Text = Valeurs[j].ToString();
                    }
                }
            }
        }
    }
}